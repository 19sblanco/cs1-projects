from password import Password

password1 = Password()
# get user input
password1.setPassword(input("Enter password: "))
password1.main()

